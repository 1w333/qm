<?php
echo "ID=".$_GET['id'];
?>